/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.showmybook;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

/**
 *
 * @author meshr
 */
public class loginTrue {
    
    

   loginTrue(String username, String password) throws IOException{
        
        File loginCreds = new File("rememberLogin.txt");
        loginCreds.createNewFile();
        FileWriter writeIt = new FileWriter("rememberLogin.txt");
        BufferedWriter writeIT = new BufferedWriter(writeIt);
            writeIT.write(username);
            writeIT.newLine();
            writeIT.write(password);
            writeIT.close();
   
    }
    
  
    
}
