package com.mycompany.showmybook;


import com.google.zxing.WriterException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class BookMyShow {
protected boolean loginStatus = false;
protected String username;
private   String password;
protected String selectedTheater;
protected String selectedTiming;
protected boolean confirmationStatus = false;
private String phoneNumber;
private int numberOfAudiences;
private int totalTicketCost;
private int selectedClassPrice;
private String selectedClass;
protected String firstname;
protected String transID;
protected String lastname;
private   String rePassword;
protected String selectedLanguage;
protected String selectedMovie;
protected String location;
private String seatRow;
private int seatNumbers;
public String feedback;
String time;
public int userRating;
String seatNumberString="";
private static final int minPasswordLength = 8;
private static final int maxPasswordLength = 20;

boolean invokeLoginClass() throws IOException{
  
       //  login1 user = new login1();
         
 Boolean userWantsLogin = this.ifUserWantsLogin();
         if(userWantsLogin){
           
        return this.allowUserToLogin();
                            
     }
         
         else{
      return this.allowUserToRegister(); 
         }
         
         
  //return false;
  
}


 boolean ifUserWantsLogin() throws FileNotFoundException{
      Scanner scanf = new Scanner(System.in);
       if(!loginRemember()){
       System.out.printf("1. Login%n2. Registration%nPlease Enter Your Choice: ");
       int decision = scanf.nextInt();
       
       return decision == 1;
    
       }  
       System.out.println("Auto Logging-in...................");
       System.out.println("Welcome Back, "+getUsersFirstName(this.username));
       return false;
   }
   
   
   
   boolean allowUserToLogin() throws IOException{
     
Scanner scanf = new Scanner(System.in);
     
     System.out.println("*Login*");
     System.out.println("Username or Phone Number: ");
     this.username = scanf.next();
     System.out.println("Password: ");
     this.password = scanf.next();
     
     if(this.validateTheUserCredentials()){
      
          
     this.askForLoginRemember();
     System.out.println("Welcome Back, "+getUsersFirstName(this.username));
     
    return true;
           
           
         }
         
         else{
           
           if(doesUserameExist(this.username))
           {
             System.out.println("Incorrect Password"); return false;
           }
           else{
             System.out.printf("Username or Phone Number Doesn't Exist %nPlease Register yourself%n");
             this.allowUserToRegister();
           }
           
           
         }
         return true;
   }


boolean validateTheUserCredentials(){
  
  int i;
 for(i = 0; i<SystemDatabase.Username.length;i++){
     if((this.username.equals(SystemDatabase.Username[i]) || this.username.equals(SystemDatabase.phoneNumber[i])) && this.password.equals(SystemDatabase.Password[i])) {
      this.loginStatus = true;
      
      return this.loginStatus;
    }
    
  }
  return false;
  
}



boolean allowUserToRegister() throws IOException{
  
  Scanner scanf = new Scanner(System.in);
  if(!loginRemember()){
  System.out.println("Registration");
  System.out.println("Enter First Name:");
  this.firstname = scanf.next();
  System.out.println("Enter Last Name: ");
  
  this.lastname = scanf.next();
  System.out.println("Enter Email Address: ");
  
  this.username = scanf.next();
  System.out.println("Enter Your Phone Number: ");
  System.out.print("+91 - ");
  this.phoneNumber = scanf.next();
 
 if(!doesUserameExist(this.username)){
    
    if(!doesPhoneNumberExist(this.phoneNumber)){
       if(validatePhoneNumber(this.phoneNumber)){
           requestPassword();
           
 
    if(validatePassword(this.password)){
  
  
  

  System.out.println("Please Re Enter the Password");
  this.rePassword = scanf.next();
    
                 
     if(doesPasswordsMatch(this.password, this.rePassword)){
          this.askForLoginRemember();
       System.out.printf("Successfully  Registered%nWelcome, "+this.firstname);
       this.loginStatus = true;
      
        return this.loginStatus;
     }
     else{
       System.out.println("Passwords Doesn't Match"); return false; 
     }
    
     }else{
        System.out.println("Please enter a valid password");
        requestPassword();
    }
       }else{
       System.out.println("Invalid Phone number. Try Again");
       this.allowUserToRegister();
     }
     }else{
       System.out.println("Phone number already exist");
       this.allowUserToRegister();
      } 
     }
     else{
       System.out.printf("Username - "+this.username+" Exists in the Server%nPlease Login%n");
       this.allowUserToLogin();
       
     }
 
    return true;
     }
  else{
      return true;
  }
}
     
   private void requestPassword(){
       Scanner scanf = new Scanner(System.in);
       System.out.printf("Enter A Password (Note: Password length must contains at least 8 and utmost 20 Characters%n with a Special Characters and Number%n):");
  this.password = scanf.next();
       
   }
   boolean doesPasswordsMatch(String password, String rePassword){
       
       
       
       return password.equals(rePassword);
     }
     
boolean validatePassword(String password){
  
       boolean capsChar = false;
       boolean splChar = false;
       boolean numberExist = false;
       boolean validLength = false;
       String[] passwordArray = password.split("");
        if(password.length() >= minPasswordLength && password.length() <= maxPasswordLength )
            validLength = true;
         for(int i = 0 ;i<password.length();i++){
             if(password.charAt(i) >= 'A' && password.charAt(i) <= 'Z') {
                 capsChar = true; break;  
             }
         }
         for(int i = 0 ;i<password.length();i++){
             if(password.charAt(i) >= ' ' && password.charAt(i) <= '/' || password.charAt(i) >= ':' && password.charAt(i) <= '@' || password.charAt(i) >= '`' && password.charAt(i) <= '~'  ){
                 splChar = true;break;
         }
         }
   
         
           for (String passwordArray1 : passwordArray) {
               try{
               if (Integer.parseInt(passwordArray1) >= 0 && Integer.parseInt(passwordArray1) <= 9) {
                   numberExist = true;
                   
                   break;
               }
           
           } catch(NumberFormatException e){}
               
           }
 
         
         
        
                
      
         
       return capsChar && splChar && numberExist && validLength ; 
         
         
        
     }
boolean doesUserameExist(String username){
       
    for (String Username : SystemDatabase.Username) {
        if (username.equals(Username)) {
            return true;
        }
    }
    return false;  
     }
     
     
     
String getUsersFirstName(String username){


for(int i=0;i<SystemDatabase.Username.length;i++){
       if(username.equals(SystemDatabase.Username[i]) || username.equals(SystemDatabase.phoneNumber[i])){
         this.firstname = SystemDatabase.firstname[i];
         this.lastname = SystemDatabase.lastname[i];
         return this.firstname;
         
       }
       
   
} 
return null;

}


boolean validatePhoneNumber(String phNumber){
  
  return (Integer.parseInt(Character.toString(phNumber.charAt(0)))>=6 && Integer.parseInt(Character.toString(phNumber.charAt(0)))<=9 && phNumber.length() == 10);
  
  
}

boolean doesPhoneNumberExist(String phNumber){
  
  for(String check : SystemDatabase.phoneNumber){
    if(check.equals(phNumber)){
      return true;
    }
  }
 return false; 
}


String showAvailableLanguagesForTheShows(){
if(this.loginStatus){
Scanner scanf = new Scanner(System.in);
System.out.println("");
  System.out.println("Available Languages"); 
  for(int i = 0 ; i < SystemDatabase.languages.length ; i++){
    
    System.out.println(i+1+". "+SystemDatabase.languages[i]);
  }
  System.out.println("Please Select a Language");
  System.out.print("Enter the Choice here: ");
  
  int selection = scanf.nextInt();  
    System.out.println(this.freezeTheLanguage(selection)+ ", language is Selected"); 
 return this.freezeTheLanguage(selection);
      }
      else{
        System.out.println("something went wrong!");
      }
      return null;
}

 String freezeTheLanguage(int languageSelection){
  if(this.loginStatus){
      try{
     this.selectedLanguage = SystemDatabase.languages[languageSelection-1];}
      catch(ArrayIndexOutOfBoundsException e){
          System.out.println("Invalid Language Choice. Try Again!");
          System.exit(0);
      }
   return this.selectedLanguage;
   }
   return null;
 }

 public  boolean loginRemember() throws FileNotFoundException{
     
        String[] userCreds = new String[2];
        File f = new File("rememberLogin.txt");
        Scanner readIt = new Scanner(f);
        boolean target = true;
        if(readIt.hasNext()){
        for(int i = 0; target == readIt.hasNext();i++){
            userCreds[i] = readIt.next();
        }
        
        this.username = userCreds[0];
        this.password = userCreds[1];
        
       
        
        validateTheUserCredentials();
        return true;
        }
     return false;
     
 }
 void askForLoginRemember() throws IOException, FileNotFoundException{

   
     
     
     
     

     System.out.println("Would You Like Remember Login Credentials: ");
     System.out.println("1. Yes");
     System.out.println("2. No");
     System.out.print("Enter Your Choice here: ");
     Scanner scanf = new Scanner(System.in);
     int choice = scanf.nextInt();
     if(choice==1){
         loginTrue loggedIn = new loginTrue("","");
         loggedIn = new loginTrue(this.username,this.password);
     }
   
 }


String showTheMovieBasedOnLanguage(String selectedLanguage)throws ArrayIndexOutOfBoundsException{
  if(this.loginStatus){
 int choice;
 Scanner scanf = new Scanner (System.in);
   System.out.println("Here's The Movies based on your Preference");
   
  
   switch(selectedLanguage){
     
    case "Kannada" : 
    for(int i = 0; i < SystemDatabase.KannadaMovies.length ; i++){
      
      System.out.println(i+1+". "+SystemDatabase.KannadaMovies[i]);
    }
    System.out.print("Enter Your Choice Here: ");     
    try{
    
    
   choice = scanf.nextInt();
   this.selectedMovie =  SystemDatabase.KannadaMovies[choice - 1];
   
  } catch (Exception e){
    System.out.println("Invalid Movie Choice");
    System.exit(0);
  } 
   
   
   
   
     return this.selectedMovie;
     
     case "Telugu":
      for(int i = 0; i < SystemDatabase.TeluguMovies.length ; i++){
      
      System.out.println(i+1+". "+SystemDatabase.TamilMovies[i]);
    }
    
    System.out.print("Enter Your Choice Here: ");
    
     try{
  int choice1 = scanf.nextInt();
   this.selectedMovie =  SystemDatabase.TamilMovies[choice1 - 1];
   }catch (Exception e){
    System.out.println("Invalid Movie Choice");
    System.exit(0);
  } 
   
   
   
   
     return this.selectedMovie; 
 case "Tamil" : 
      for(int i = 0; i < SystemDatabase.TeluguMovies.length ; i++){
      
      System.out.println(i+1+". "+SystemDatabase.TamilMovies[i]);
    }
    
    System.out.print("Enter Your Choice Here: ");
    try{
     
  int choice2 = scanf.nextInt();
   this.selectedMovie =  SystemDatabase.TamilMovies[choice2 - 1];
   
   
   }
   catch (Exception e){
    System.out.println("Invalid Movie Choice");
    System.exit(0);
  } 
   
   
   
     return this.selectedMovie; 
     
 case "Hindi" : 
      for(int i = 0; i < SystemDatabase.HindiMovies.length ; i++){
      
      System.out.println(i+1+". "+SystemDatabase.HindiMovies[i]);
    }
    
    System.out.print("Enter Your Choice Here: "); 
    try{
     
  int choice3 = scanf.nextInt();
   this.selectedMovie =  SystemDatabase.HindiMovies[choice3 - 1];
   }catch (Exception e){
    System.out.println("Invalid Movie Choice");
    System.exit(0);
  } 
   
   
   
   
     return this.selectedMovie;    
     
 case "English" : 
      for(int i = 0; i < SystemDatabase.EnglishMovies.length ; i++){
      
      System.out.println(i+1+". "+SystemDatabase.EnglishMovies[i]);
    }
    
    System.out.print("Enter Your Choice Here: ");
    try{
     
  int choice4 = scanf.nextInt(); 
   this.selectedMovie =  SystemDatabase.EnglishMovies[choice4 - 1];
   }catch (Exception e){
    System.out.println("Invalid Movie Choice");
    System.exit(0);
  } 
   
   
     return this.selectedMovie;    
     
  case "Malayalam" : 
     for(int i = 0; i < SystemDatabase.MalayalamMovies.length ; i++){
      
      System.out.println(i+1+". "+SystemDatabase.MalayalamMovies[i]);
    }
    
    System.out.print("Enter Your Choice Here: ");
    try{
     
  int choice4 = scanf.nextInt(); 
   this.selectedMovie =  SystemDatabase.MalayalamMovies[choice4 - 1];
   }catch (Exception e){
    System.out.println("Invalid Movie Choice");
    System.exit(0);
  } 
   
   
     return this.selectedMovie;    
     
   }
  
   
return null;
}
return null;
}


String setLocation(){
if(this.loginStatus){
  Scanner scanf = new Scanner(System.in);
  System.out.print("Enter Your Location: ");
  this.location = scanf.next();
  
  return this.location;
 }
 return null; 
}


String showClosestTheaterWithShowTimings(){
if(this.loginStatus){
  Scanner scanf = new Scanner(System.in);


  System.out.println("Based On your location Theaters are Sorted:");
  for(int i = 0; i < SystemDatabase.TheatersMovie.length; i++){
    
    System.out.print(i+1+". "+SystemDatabase.TheatersMovie[i]+" - ");
    for(String time : SystemDatabase.ShowTimings){
   System.out.print(time + " "); 
    }
    System.out.println("");
  }
   System.out.printf("Please Select a Theater: ");
   try{
  int choice = scanf.nextInt();
  this.selectedTheater = SystemDatabase.theaters[choice - 1];
   }catch (Exception e){
    System.out.println("Invalid Theater Choice");
    System.exit(0);
  } 
   
   
   
   
   
    System.out.println(this.selectedTheater+", has been Selected");
    System.out.println("***Timings chart**");
    
    for(int i = 0; i < SystemDatabase.ShowTimings.length; i++){
    if(SystemDatabase.ShowTimings[i].equals("10:30")){
    System.out.print(i+1+". "+SystemDatabase.ShowTimings[i]+" "+"AM");
            this.time="AM";
    }
    else{
         System.out.print(i+1+". "+SystemDatabase.ShowTimings[i]+" "+"PM");
         this.time = "PM";
    }
    System.out.println("");
  }
  
    System.out.print("Choose your Desired Timings for Show: ");
int    choice = scanf.nextInt();
    
    try{
    this.selectedTiming = SystemDatabase.ShowTimings[choice-1];
   }catch (Exception e){
    System.out.println("Invalid Show Timings Choice");
    System.exit(0);
  } 
   
   
   
    System.out.println(this.selectedTiming+" "+this.time+", has been Selected");
System.out.println(this.showClassesInTheater()+ " class is selected!"); 
    
  
  }
  return null;
}


boolean bookTheTicket(){

if(this.loginStatus){
  Scanner scanf = new Scanner(System.in);
  System.out.println("***Ticket Booking Process***");
  System.out.print("Please Enter total number of Audience(s): ");
  
 this.numberOfAudiences = scanf.nextInt();
  
  this.totalTicketCost = this.selectedClassPrice * this.numberOfAudiences;
  
  
  System.out.println("Total Ticket Cost: "+this.totalTicketCost+" Rs");
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  System.out.printf("1. Book your Ticket%n2. Cancel%n");
  
  System.out.print("Enter Your Choice here: ");
  int choice = scanf.nextInt();
  if(choice == 1){
    return true;
  }
  else{
    System.out.println("Ticket Booking Process has been Cancelled");
    return false;
  }
  }
  return false;
}




boolean initiatePaymentGateway(){
if(this.loginStatus){
  Scanner scanf = new Scanner(System.in);
  System.out.println("****PAYMENT GATEWAY*****");
  
  System.out.printf("1. Credit Card%n2. Debit Card%n3. UPI");
  System.out.printf("%nEnter Your Choice here: ");
  int choice = scanf.nextInt();
 System.out.println("***********");
 // int choice = scanf.nextInt();
    switch(choice){

      case 1 : this.confirmationStatus =this.initiateCreditCardPayment();
      return this.confirmationStatus;
      case 2 : this.confirmationStatus = this.initiateDebitCardPayment();
      return this.confirmationStatus;
      case 3: this.confirmationStatus = this.initiateUPIPayment();
      return this.confirmationStatus;
      default : System.out.println("Sorry! Invalid payment method"); return false;
      
    }
  }
  return false;
}

boolean initiateCreditCardPayment(){
if(this.loginStatus){
  
  Scanner scanf = new Scanner(System.in);
  System.out.println("Enter Your Credit Card Number");
  
  String cardNumber = scanf.next();
  System.out.println("Enter the Card Expiry Month and Year (MM/YYYY)");
  String expiryMonth = scanf.next();
  System.out.println("Enter The Card CVV number");
  String cvv = scanf.next();
 BankServer bank = new BankServer(cardNumber, expiryMonth, cvv);
  if(bank.validateCard()){
    System.out.println("Card is Accepted");
    System.out.printf("1. Make Payment%n2. Cancel%nEnter Your Choice here: ");
    int choice = scanf.nextInt();
     if(choice == 1){
     
      return true;
    }
    else{
        System.out.println("Payment has been cancelled. Thank you!");
      return false;
    }
    
  }else{
    System.out.println("Invalid Credentials!. Payment is Terminated!");
    
    
  }
 return false;
 }
 return false;
  
}


boolean initiateDebitCardPayment(){
  if(this.loginStatus){
  Scanner scanf = new Scanner(System.in);
  System.out.println("Enter Your Debit Card Number");
  
  String cardNumber = scanf.next();
  System.out.println("Enter the Card Expiry Month and Year (MM/YYYY)");
  String expiryMonth = scanf.next();
  System.out.println("Enter The Card CVV number");
  String cvv = scanf.next();
BankServer  bank = new BankServer(cardNumber, expiryMonth, cvv);
  if(bank.validateCard()){
    System.out.println("Card is Accepted");
    System.out.printf("1. Make Payment%n2. Cancel");
int    choice = scanf.nextInt();
      if(choice == 1){
      return true;
    }
    else{
        System.out.println("Payment has been cancelled. Thank you!");
      return false;
    }
  
    
  }
 else{
    System.out.println("Invalid Card Details!. Payment is Terminated!");
    
}
return false;
}
return false;
}
boolean initiateUPIPayment(){
  
  
  if(this.loginStatus){
  Scanner scanf = new Scanner(System.in);
  System.out.println("Enter Your UPI Number");
  
  String upiNumber = scanf.next();
BankServer bank = new BankServer(upiNumber);

  if(bank.validateUPI()){
    System.out.println("UPI number is Accepted");
    System.out.printf("1. Make Payment%n2. Cancel%n");
    System.out.print("Enter Your Choice here: ");
 int   choice = scanf.nextInt();
    if(choice == 1){
      return true;
    }
    else{
        System.out.println("Payment has been cancelled. Thank you!");
      return false;
    }
    
  }
  
  else{
    System.out.println("Invalid UPI Number!. Payment is Terminated!");
    
    
  }
  return false;
  }
  return false;
}

void generateTicketSummary(){
   
    if(this.loginStatus){
    this.generateSeatNumbers();
        System.out.println("**PRINTING TICKET SUMMARY**");
        System.out.println("Language: "+this.selectedLanguage);
        System.out.println("Movie: "+this.selectedMovie);
        System.out.println("Theater: "+this.selectedTheater);
        System.out.println("Show Timing: "+ this.selectedTiming);
        System.out.println("Class: "+this.selectedClass);
       String[] seat = new String[50];
        System.out.print("Allocated Seats: ");
        for(int i = this.seatNumbers ; i  <= this.seatNumbers+this.numberOfAudiences ; i++){
            this.seatNumberString = this.seatNumberString+this.seatRow+i+", ";
          System.out.print(this.seatRow+i+" ");
        }
       
      
      System.out.println("");
        if(this.confirmationStatus){
        System.out.println("Ticket Confirmation Status: Confirmed");
      
        }
        else{
         System.out.println("Ticket Confirmation Status: Failed");
        }        
   System.out.println("************"); 
    
    
    }
    
    
}


void generateTransactionID(){
  
  if(this.loginStatus){  if(this.confirmationStatus){
    
    this.transID = SystemDatabase.randomString();
    
    }
    
  }
  
  
  }
  
  boolean userWantsCancellation(){
 if(this.loginStatus){
 Scanner scanf = new Scanner(System.in);
   System.out.println("Would You like Cancel the Ticket?");
   System.out.println("1. Yes");
   System.out.println("2. No");
   System.out.print("Please Enter your choice: ");
   int choice = scanf.nextInt();
   return choice == 1;
   }
   return false; 
 }
  
  
boolean logoutPrompt() throws FileNotFoundException, IOException{
if(this.loginStatus){
  Scanner scanf = new Scanner(System.in);
  System.out.println("");
  System.out.println("***LOGOUT PROMPT****");
  System.out.println("Would you like to logout from the System!?");
  System.out.println("1. Logout");
  System.out.println("2. Cancel");
  System.out.print("Please Enter your choice: ");
  int choice = scanf.nextInt();
  if(choice == 1){
    FileWriter fr = new FileWriter("rememberLogin.txt");
    BufferedWriter readIt = new BufferedWriter(fr);
        readIt.write("");
        readIt.newLine();
        readIt.write("");
        readIt.close();
    this.loginStatus = false; 
  }
  
  
  return choice == 1;
  
  }
  return false;
}

 String showClassesInTheater(){
 if(this.loginStatus){
  Scanner scanf = new Scanner(System.in);
  System.out.println("Available Classes in "+this.selectedTheater+" theater");
  int i = 1;
  for(String show : SystemDatabase.classesInTheater){
    System.out.println(i+". "+show + " - "+SystemDatabase.classPrices[i-1]+" Rs");
    i++;
  }
  System.out.print("Choose a Class: ");
  try{
  int choice = scanf.nextInt();
  this.selectedClass = SystemDatabase.classesInTheater[choice - 1];
  this.selectedClassPrice = SystemDatabase.classPrices[choice - 1];
 return this.selectedClass;  
 } catch (Exception e){
   System.out.println("Invalid choice");
   return null;
 }
 }
 return null;
}

void displayOrderSummary(){
  
  
 if(this.loginStatus){
     
     System.out.println("Payment Successful!");
     System.out.println("*****Order Summary*****");
  
  System.out.println("Transaction ID: "+this.transID);
  System.out.println("Amount Debited: "+this.totalTicketCost + " Rs");
  System.out.println("Paid to: ShowMyBook Corp.");
  System.out.println("Confirmation of the ticket will be sent to the Registered Phone number, Shortly.");
System.out.println("***********");  
      }
}



void ratingAndFeedback(){
System.out.println("");
Scanner scanf = new Scanner(System.in);
  System.out.println("Please Give Rating and Feedback about the Movie: "+ this.selectedMovie);
 System.out.println("Rating Chart");
 System.out.println("1. ★");
 System.out.println("2. ★★");
 System.out.println("3. ★★★");
 System.out.println("4. ★★★★");
 System.out.println("5. ★★★★★");
 System.out.print("Choose your Rating: ");
 int choice = scanf.nextInt();
 if(choice >= 1 && choice<=5){
   this.userRating = choice;
   System.out.println("Type in your Comment Below");
  this.feedback = scanf.next();
  
 }
 else{
   System.out.println("Invalid Choice");
 }
  
  
  
  
}



void generateQRForTicket() throws IOException, WriterException{
    
    String qrCodeText = "Your Ticket\n"+"Language:" +this.selectedLanguage+"\nMovie: "+this.selectedMovie+"\nTheater: "+this.selectedTheater+
   "\nShow Timing: "+ this.selectedTiming + "\nClass: "+this.selectedClass+ "\nSeat Number: "+this.seatNumberString;
		String filePath = "ticket.png";
		int size = 125;
		String fileType = "png";
		File qrFile = new File(filePath);
		TicketQRCode.createQRImage(qrFile, qrCodeText, size, fileType);
		
    
    
    
}

String generateSeatNumbers(){
  
  
  if(this.loginStatus){
    
     
   this.seatRow = SystemDatabase.seatRow();
   this.seatNumbers = Integer.parseInt(SystemDatabase.seatNumber());
   return this.seatRow;
    
   
  }
  
  return null;
  
}

    void displayQRCode()throws IOException {
       displayQRCode QR = new displayQRCode(this.selectedMovie);
    }

   

   
}