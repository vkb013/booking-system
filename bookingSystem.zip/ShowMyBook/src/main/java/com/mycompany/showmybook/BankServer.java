
package com.mycompany.showmybook;

public class BankServer {
  private String cardNumber;
  private String upiNumber;
  private String cvv;
  private String expiryMonth;
private final String handlesUpi[] ="obc3,rbl4,upi5,allbank6,axisbank7,indus8,federal9,sbi10,citi,citigold11,okhdfcbank ,okaxis,oksbi,okicici12,hsbc13,icici14,ybl".split("\\,");
  
  
  
  
  
 
  
  
  
  
  
  
  
  BankServer(String CardNumber, String expiryMonth, String cvv){
    this.cardNumber = CardNumber;
    this.expiryMonth = expiryMonth;
    this.cvv = cvv;
  }
  BankServer(String upiNumber){
    this.upiNumber = upiNumber;
  }
  
  boolean validateCard(){
    
    
    return (this.cardNumber.length() == 16 && this.validateExpiryDate() && this.cvv.length() == 3);
    
    
  }
Boolean validateExpiryDate() {
    
    int month;
    int year;
  try{
    String monthCumYear[] = this.expiryMonth.split("/");
    
    
   month = Integer.parseInt(monthCumYear[0]);
   // System.out.println(month);
    year = Integer.parseInt(monthCumYear[1]);
    
   return ((month >= 1 && month <= 12) && (year >=2020)); 
 
  }catch(Exception e){
      System.out.println("Invalid Expiry Month/Year Format");
  }
  return false;
}
  
  
  boolean validateUPI(){
  String upiNumberAnatomy[] = this.upiNumber.split("\\@");
  String phoneNumber = upiNumberAnatomy[0];
  String handle = upiNumberAnatomy[1];
 
  boolean value1 = phoneNumber.length()==10 && (phoneNumber.charAt(0) == '6' || phoneNumber.charAt(0) == '7' || phoneNumber.charAt(0) == '8' || phoneNumber.charAt(0) == '9');
 
  boolean value2 = false;
  for(String check : handlesUpi){
 
    if(handle.equals(check)){
      value2 = true;
      break;
    }
    
  }

  if(!value2){
    System.out.println("Sorry! We don't Support @"+handle+" UPI Handle");
  }
  
  
  return value1 && value2;
  
  
    
  }

}