
package com.mycompany.showmybook;


import java.awt.FlowLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

public class displayQRCode {

 

    public displayQRCode(String movieName) throws IOException
    {
        BufferedImage img=ImageIO.read(new File("C:\\Users\\meshr\\OneDrive\\Documents\\NetBeansProjects\\ShowMyBook\\ticket.png"));
        ImageIcon icon=new ImageIcon(img);
        JFrame frame=new JFrame("ShowMyBook - Scan QR for your Ticket( Movie: "+movieName+" )");
        
        frame.setLayout(new FlowLayout());
        frame.setSize(1000,300);
        JLabel lbl=new JLabel();
        lbl.setIcon(icon);
        frame.add(lbl);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}